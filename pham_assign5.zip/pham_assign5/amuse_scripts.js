/* Bao Pham
   Date: 11/28/2021
   Assignment 5
*/
function outputUpdate(dollars) {
	document.querySelector('#donationAmount').value=('$' +dollars);
	}

function rideInfo (ride,id) {
    alert ('You clicked on the ride: ' + ride + ' with the ID is: ' + id);
    }

//Assignment 5

var rideNames= ["Space Mountain", "Expedition Everest - Legend of the Forbidden Mountain", "Jungle Cruise", 
"Awesome Planet" ,"Big Thunder Mountain Railroad"];

var rideDescriptions= ["Blast off on a rip-roaring rocket into the furthest reaches of outer space on this roller-coaster ride in the dark.",
"Careen through icy Himalayan peaks on a speeding train while avoiding the clutches of the mythic Yeti.",
"Chart a course for high adventure on a scenic and comedic boat tour of exotic rivers across Asia, Africa and South America.",
"Immerse yourself in a stunning 10-minute film featuring spectacular imagery from across the globe.",
"Race through a haunted gold mine aboard a speeding train on this thrilling coaster-style ride."];

var rideImage= ["images/space_mountain.jpg", "images/everest.JPG", "images/jungle_cruise.jpg", "images/awesome-planet.jpg", "images/big_thunder.jpg"];

function repeatN(){
    for(i=0; i<5; i++){
        listOfName = "title" +(i+1);
        document.getElementById(listOfName).innerHTML = rideNames[i];
    }
}

function repeatPictures(){
    for(i=0; i<5; i++){
        listOfP = "pics" +(i+1);
        document.getElementById(listOfP).innerHTML = rideImage[i];
    } 
}

function repeatDetails(){
    for(i=0; i<5; i++){
        listOfDet = "sentence" + (i+1);
        document.getElementById(listOfDet).innerHTML = rideDescriptions[i];
    }
}


if(window.addEventListener){
    window.addEventListener("load", showRides, false);
} else if(window.attachEvent){
    window.attachEvent("onload", showRides);
}


function showRides(){
    repeatN();
    repeatPictures();
    repeatDetails();
}



// Part B 

function order() {
    x = document.forms["order"]["contName", "gmail", "phone", "yearold"].value;
    if (x=="") {
       alert("Please fill out all Contact Information fields!");
       return false;
    }
    else {
       alert("Thank you for filling out the form!");
    }
    document.getElementById("submit").addEventListener("click", order, false);
   }
   